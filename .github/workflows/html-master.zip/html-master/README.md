# HTML

Per the [MOU of W3C and WHATWG](https://www.w3.org/blog/2019/05/w3c-and-whatwg-to-work-together-to-advance-the-open-web-platform/), W3C and WHATWG will work together on HTML and DOM in the [WHATWG repositories](https://github.com/whatwg/html), to produce a Living Standard and W3C Recommendations. This repository has been archived for historical purposes and is no longer maitained.


## Old HTML repository

The [old HTML repo](https://github.com/w3c/html-old) is available for archival purposes.
